#include "generatehah.h"
#include "ui_generatehah.h"
#include"mainwindow.h"
#include"compareimage.h"
#include<QFileDialog>
#include <QMessageBox>
QString pic="";
GenerateHah::GenerateHah(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GenerateHah)
{
    ui->setupUi(this);


}

GenerateHah::~GenerateHah()
{
    delete ui;
}

void GenerateHah::on_FileDialog_clicked()
{
        QString filename=QFileDialog::getOpenFileName(this,tr("Open File"),"/home/paresh",tr("Image Files (*.png *.jpg *.bmp)"));
        pic=filename;

        ui->FilePath->setText(pic);
        QPixmap pix(pic);
        int w = ui->label_image->width();
        int h = ui->label_image->height();
        ui->label_image->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
        QMessageBox::information(this,tr("File Uploaded"),"file uploded successfully");
        ui->FileDialog->setEnabled(false);
        ui->label->setVisible(false);
        QMessageBox::information(this,tr(""),"To generate Hash click generate button");
}

void GenerateHah::on_Home_clicked()
{
    this->close();
}


void GenerateHah::on_cmp_clicked()
{
    this->close();
    CompareImage cmpi;
    cmpi.setModal(true);
    cmpi.exec();
}

void GenerateHah::on_hashgen_clicked()
{
    //call hash generation function
     // set text
    ui->hash->setText(pic);
}
