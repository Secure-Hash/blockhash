#ifndef GENERATEHAH_H
#define GENERATEHAH_H


#include<QDialog>


namespace Ui {
class GenerateHah;
}

class GenerateHah : public QDialog
{
    Q_OBJECT

public:
    explicit GenerateHah(QWidget *parent = 0);
    ~GenerateHah();

private slots:
   void on_FileDialog_clicked();

   void on_Home_clicked();

   void on_cmp_clicked();

   void on_hashgen_clicked();

private:
    Ui::GenerateHah *ui;
};

#endif // GENERATEHAH_H
