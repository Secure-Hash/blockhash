#include "compareimage.h"
#include "ui_compareimage.h"

CompareImage::CompareImage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CompareImage)
{

    ui->setupUi(this);
}

CompareImage::~CompareImage()
{
    delete ui;
}

void CompareImage::on_cmp_clicked()
{
    //hash cmp function call

}
